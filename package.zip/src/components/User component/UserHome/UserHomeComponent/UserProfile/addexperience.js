import React from 'react'
import { Card } from "./Card/Card";
import { FormInputs } from "./FormInputs/FormInputs";
import {
    Grid,
    Row,
    Col,
    FormGroup,
    ControlLabel,
    FormControl
  } from "react-bootstrap";
import NavComponent from '../../NavbarComponent/NavComponent';

class AddExperience extends React.Component {
    render(){
        return(
            <div>
                <NavComponent/>
            <div align="center">
                <h2>Add Experience</h2>
                <form>
                    <FormInputs
                      ncols={["col-md-4 col-md-offset-4" ]}
                      proprieties={[
                        {
                          label: "Previous Company ",
                          type: "text",
                          bsClass: "form-control",
                          placeholder: "Company",
                          defaultValue: "",
                          
                        }
                      ]}
                      />
                      <FormInputs
                      ncols={["col-md-4 col-md-offset-4"]}
                      proprieties={[
                        {
                          label: "Job Duration",
                          type: "text",
                          bsClass: "form-control",
                          placeholder: "Duration",
                          defaultValue: ""
                        }
                      ]}
                      />
                      <FormInputs
                      ncols={["col-md-4 col-md-offset-4"]}
                      proprieties={[
                        {
                          label: "Technology",
                          type: "text",
                          bsClass: "form-control",
                          placeholder: "technology"
                        }
                      ]}
                    />
                    <FormInputs
                      ncols={["col-md-4 col-md-offset-4"]}
                      proprieties={[
                        {
                          label: "No of Project",
                          type: "text",
                          bsClass: "form-control",
                          placeholder: "no of project",
                          defaultValue: ""
                        }
                      ]}
                      />
                      <FormInputs
                      ncols={["col-md-4 col-md-offset-4"]}
                      proprieties={[
                        {
                          label: "Years of experience",
                          type: "text",
                          bsClass: "form-control",
                          placeholder: "experience ",
                          defaultValue: ""
                        }
                      ]}
                    />
                    
                    <button bsStyle="info" pullRight fill type="submit" className="btn btn-success">
                      Update Experience
                    </button>
                    <div className="clearfix" />
                  </form>
            </div>
            </div>
        )
    }
}
export default AddExperience