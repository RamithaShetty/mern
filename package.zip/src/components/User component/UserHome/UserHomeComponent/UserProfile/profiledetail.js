import React, { Component } from "react";
import {Row,Col,FormGroup,ControlLabel,FormControl } from "react-bootstrap";
import avatar from "./images/profileImage.png";
import UserCard from './UserCard/UserCard'
import NavComponent from "../../NavbarComponent/NavComponent";
class UserProfile extends Component {


  render() {
    return (
      <div className="content">
        <NavComponent/>
        
          
              <UserCard
                avatar={avatar}
                name="Mike Andrew"
                userName="michael24"
                description={
                  <span>
                    "Lamborghini Mercy
                    <br />
                    Your chick she so thirsty
                    <br />
                    I'm in that two seat Lambo"
                  </span>
                }
                socials={
                  <div>
                    <button>
                      <i className="fab fa-facebook-square fa-2x" />
                    </button>
                    <button>
                      <i className="fab fa-twitter fa-2x" />
                    </button>
                    <button>
                      <i className="fab fa-google-plus-square fa-2x" />
                    </button>
                  </div>
                }
              />
          
         
       
        <div>
          <a href={'/editprofile'} className="btn btn-warning btn-block">Edit Profile</a>
          <br />
          <br />
          <a href={'/addexperience'} className="btn btn-primary btn-block">Add Experience</a>
          <br />
          <br />
          <a href={'/addskill'} className="btn btn-success btn-block">Add Skill</a>
        </div>
      </div>
    );
  }
}

export default UserProfile;