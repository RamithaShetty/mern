import React from "react";


import { Link } from "react-router-dom";
import images from "../NavbarComponent/images/down.png";

export const NavComponent = () => {
  return (
    <div className="row">
        <div className="col-lg-2">
        <img src={images} width="120px" height="100px" />
        </div>
        <div className="col-lg-5">
        
        <div class="search-container">
          
          <input type="text" className="text-center" placeholder="Search"/>
          &nbsp;&nbsp;
          <button><i className=" fas fa-search fa-2x" variant="outline-info"></i></button>
           </div>
          
           </div>
           <div className="col-lg-5">
           
    <nav className="navbar navbar-expand-lg navbar-light bg-light ">
      <div className="container-fluid">
        <div className="navbar-header">
          &nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        
        <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav navbar-right">
            <li>
              <Link className="fas fa-home fa-3x" to="/userhome">&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li>
              <Link  className="fas fa-briefcase fa-3x" to="/managejob">&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <span className="sr-only" />
            </li>
            <li>
              <Link className="fas fa-users fa-3x" to="/network" >&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li>
              <Link className="fas fa-user fa-3x" to="/userprofile" >&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li>
              <Link className="fa fa-bell fa-3x" to="/notifications">
       
                <span className ="badge badge-info">2</span>&nbsp;&nbsp;

              </Link>
              &nbsp;&nbsp;&nbsp;&nbsp;
            </li>
          </ul>
         </div>
         </div>
    </div>   
    </nav>
    </div>
    
    </div>
    
    
  );
};

export default NavComponent;
