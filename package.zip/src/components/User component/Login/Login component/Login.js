import React from "react";
import {BrowserRouter as Router, Link} from "react-router-dom"

import image from './images/down.png';
import Registration from "../../Registration/Registration component/Registration";


class Login extends React.Component {
    routeChangeReg=(e)=> {
        let path = `/registration`;
        this.props.history.push(path);
      }
    render() {
        return(
             <div style={{backgroundColor: "brown"}}>
            <Router>      
<br/><br/><br/><br/><br/><br/><br/><br/><br/>
                <div className="row justify-content-md-center"> 
                	<div className="col-md-5 col-xs-5" >
                <div className="card">
                <div className="row justify-content-md-center">
					<center>
                    <img src={image} align="center" width="140px" height="100px"/>
						<h1 className="card-title" className="margin-top-30">Login here...</h1><br />
						{/* <label align="left">Email:</label> */}
						<input type="email" ref="email" placeholder="Enter Email" className="form-control" /><br />
						{/* <label>Password:</label> */}
                        <input type="password" ref="password" placeholder="Enter Password" className="form-control" /><br />
						<button className="btn btn-primary margin-bottom-10" >Login</button>&nbsp;&nbsp;&nbsp;
                        <button className="btn btn-warning margin-bottom-10" >Forgot Password ?</button>
                        <br />
                        <br />
						Not a user? <button className="btn btn-link" onClick={e => this.routeChangeReg(e)}>Sign up!</button>
                        <br/>
                        <br/>
					</center>
				</div>
			</div>
            </div> 
            </div>   
            <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>  
            </Router>    
           
            </div>    
        )
}
}
export default Login;
