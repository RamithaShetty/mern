import React from 'react';

class Home extends React.Component {
    routeChangeGet = (e) => {
        let path = '/registration';
        this.props.history.push(path)
    }

    routeChangeGet1 = (e) => {
        let path = '/register';
        this.props.history.push(path)
    }
    render() {
        return (
            <div>
                
                <h2>Welcome to Home Page</h2>
                <br/><br/> &nbsp;
                <button className="btn btn-primary" onClick={e => this.routeChangeGet(e)}>Register as User</button>
               &nbsp; &nbsp;
                <button className="btn btn-success" onClick={e => this.routeChangeGet1(e)}>Register as Organization</button>
               
            </div>
        )
    }
}
export default Home;